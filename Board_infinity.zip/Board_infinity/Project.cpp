#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

struct Book {
 // Attributes required for any book that is id,title,author etc.
    int id;
    string title;     
    string author;
    bool isIssued;
    string issuedTo;
};

//Function for adding the book into the Library
void addBook(vector<Book>& books, int id, string title, string author) {         //1. A function with name addBook having four parameter
    Book newBook = {id, title, author, false, ""};                               //2. vector of structure Book type with taking reference books,id,title and author
    books.push_back(newBook);                                                    //3. After that object of Book is created as newBook that is assigning 5 things
    cout << "Book added successfully.\n";                                        //4. After that we inserting the object into the vector using push_back keywords
}                                                                                //5. Just printing that book is added successfully



//Function for Searching the books by id in the library
void searchBookById(const vector<Book>& books, int id) {
    for (const auto& book : books) {
        if (book.id == id) {
            cout << "Book Found: ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Status: " << (book.isIssued ? "Issued" : "Available") << "\n";
            return;
        }                                                                        //1. Function with name searchBookById for searching the book into the library.
    }                                                                            //2. Having the 2 parameter i.e. vector and id.
    cout << "Book not found.\n";                                                 //3. For each loop is used to traverse each books of the library,and in this conditional statement is there to proceed further.
}                                                                                //4. if book is present then details of the books should printed otherwise book not found printed.



//Fuction for Searching the book by title in the library
void searchBookByTitle(const vector<Book>& books, const string& title) {
    for (const auto& book : books) {                                              // In this all the things remains the same as above only in place of id there is string
        if (book.title == title) {
            cout << "Book Found: ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Status: " << (book.isIssued ? "Issued" : "Available") << "\n";
            return;
        }
    }
    cout << "Book not found.\n";
}

//Function for issuing the book from library
void issueBook(vector<Book>& books, int id, const string& studentName) {
    for (auto& book : books) {                                                   //1. A function with name issueBook with having the 3 parameters.
        if (book.id == id && !book.isIssued) {                                   //2. Three parameters:- i.e.vector,id and studentName
            book.isIssued = true;                                                //3. For each loop is used to traverse each book in the library
            book.issuedTo = studentName;                                         //4. if is used with condition and if condtion is true then book is issued to the person
            cout << "Book issued to " << studentName << ".\n";                   //5. Otherwise not issued
            return;
        }
    }
    cout << "Book not available for issuing.\n";
}

//Function for returning the book to the library
void returnBook(vector<Book>& books, int id) {                                  // This function mainly used for returning the book to the library
    for (auto& book : books) {                                                  // This function should traverse the whole library and after that conditional statement is used with some conditions. 
        if (book.id == id && book.isIssued) {                                   // If the book find with the id then if block executed and book returned successfully.
            book.isIssued = false;
            book.issuedTo = "";
            cout << "Book returned successfully.\n";
            return;
        }
    }
    cout << "Book not found or not issued.\n";
}

//Function for Displaying the book present in the library
void listBooks(const vector<Book>& books) {
    vector<Book> sortedBooks = books;
    sort(sortedBooks.begin(), sortedBooks.end(), [](const Book& a, const Book& b) {            
        return a.title < b.title;
    });
    for (const auto& book : sortedBooks) {
        cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Status: " << (book.isIssued ? "Issued" : "Available") << "\n";
    }
}

void deleteBook(vector<Book>& books, int id) {
    auto it = remove_if(books.begin(), books.end(), [id](const Book& book) {
        return book.id == id;
    });
    if (it != books.end()) {
        books.erase(it, books.end());
        cout << "Book deleted successfully.\n";
    } else {
        cout << "Book not found.\n";
    }
}

int main() {
    vector<Book> books;
    int choice, id;
    string title, author, studentName;

    while (true) {
        cout << "Library Management System\n";
        cout << "1. Add Book\n2. Search Book by ID\n3. Search Book by Title\n4. Issue Book\n5. Return Book\n6. List All Books\n7. Delete Book\n8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Book ID, Title and Author: ";
                cin >> id >> ws;
                getline(cin, title);
                getline(cin, author);
                addBook(books, id, title, author);
                break;
            case 2:
                cout << "Enter Book ID: ";
                cin >> id;
                searchBookById(books, id);
                break;
            case 3:
                cout << "Enter Book Title: ";
                cin >> ws;
                getline(cin, title);
                searchBookByTitle(books, title);
                break;
            case 4:
                cout << "Enter Book ID and Student Name: ";
                cin >> id >> ws;
                getline(cin, studentName);
                issueBook(books, id, studentName);
                break;
            case 5:
                cout << "Enter Book ID: ";
                cin >> id;
                returnBook(books, id);
                break;
            case 6:
                listBooks(books);
                break;
            case 7:
                cout << "Enter Book ID: ";
                cin >> id;
                deleteBook(books, id);
                break;
            case 8:
                return 0;
            default:
                cout << "Invalid choice, please try again.\n";
        }
    }

    return 0;
}
